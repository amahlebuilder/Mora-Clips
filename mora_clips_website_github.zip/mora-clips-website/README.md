# Mora Clips website

A responsive, single-page website for Mora Clips.

## Publish with GitHub Pages
1. Create a new GitHub repository (for example, `mora-clips-site`).
2. Upload `index.html` to the repository's root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish your site.

## Contact details
- Business email: `moraacquisitions@gmail.com`
- Phone / WhatsApp: intentionally left as a placeholder until the owner supplies the number.

## Before publishing
- Confirm the package scope, revision count and delivery windows are operationally realistic.
- Add a real founder introduction or photograph if desired. The current About section deliberately avoids inventing a founder biography.
- Add your confirmed phone/WhatsApp number once supplied.
- Confirm the USD pricing and any payment/deposit terms.
- The social platform names and icons in the hero are illustrative interface elements, not endorsements or official platform integrations.

The page is built with HTML/CSS/vanilla JavaScript. Google Fonts are loaded online; if unavailable, system fallbacks are used. The hero's layered 3D still-life is made with CSS, so there is no heavy 3D library or external asset requirement.
